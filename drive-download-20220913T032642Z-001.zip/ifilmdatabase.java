package kyle.five;

public interface ifilmdatabase {

	// Abstract method to use in child classes
	public abstract void addToDatabase();

	public abstract void userinput();

}
